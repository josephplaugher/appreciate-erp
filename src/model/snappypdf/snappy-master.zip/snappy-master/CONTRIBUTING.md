
# Thanks for contributing!


## Before adding issues

Please verify the problem is actually a snappy problem and not a **wkhtmltopdf problem**.

To do so, simply copy paste the command displayed in the error message in your command prompt.  
If the same error appears on the command line, then it's a wkhtmltopdf problem,
and you'll have more chance to resolve your issue [there](https://github.com/wkhtmltopdf/wkhtmltopdf/issues).
